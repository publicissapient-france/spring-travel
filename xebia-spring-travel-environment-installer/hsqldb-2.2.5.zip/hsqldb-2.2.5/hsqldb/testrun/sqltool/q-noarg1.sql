/*
 * $Id: q-noarg1.sql 610 2008-12-22 15:54:18Z unsaved $
 *
 * Simplest test of \q with no args
 */

\p Just quitting.  Should exit with 0 (success) exit status.
\q
