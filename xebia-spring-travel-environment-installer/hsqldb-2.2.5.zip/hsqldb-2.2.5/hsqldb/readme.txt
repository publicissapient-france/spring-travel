Readme File
$Date: 2011-06-26 09:51:30 -0400 (Sun, 26 Jun 2011) $
This package contains HyperSQL v. 2.2.5

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
